import { useMutation } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { z } from "zod";

export function useSymptomRemedy() {
  return useMutation({
    mutationFn: async (data: z.infer<typeof api.ai.symptomRemedy.input>) => {
      const validated = api.ai.symptomRemedy.input.parse(data);
      const res = await fetch(api.ai.symptomRemedy.path, {
        method: api.ai.symptomRemedy.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to get AI remedy");
      return api.ai.symptomRemedy.responses[200].parse(await res.json());
    },
  });
}

export function useCycleInsights() {
  return useMutation({
    mutationFn: async (data: z.infer<typeof api.ai.cycleInsights.input>) => {
      const validated = api.ai.cycleInsights.input.parse(data);
      const res = await fetch(api.ai.cycleInsights.path, {
        method: api.ai.cycleInsights.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to get cycle insights");
      return api.ai.cycleInsights.responses[200].parse(await res.json());
    },
  });
}
