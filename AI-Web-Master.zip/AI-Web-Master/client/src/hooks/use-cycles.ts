import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { z } from "zod";

export function useCycles() {
  return useQuery({
    queryKey: [api.cycles.list.path],
    queryFn: async () => {
      const res = await fetch(api.cycles.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch cycles");
      return api.cycles.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateCycle() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: z.infer<typeof api.cycles.create.input>) => {
      const validated = api.cycles.create.input.parse(data);
      const res = await fetch(api.cycles.create.path, {
        method: api.cycles.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create cycle");
      return api.cycles.create.responses[201].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.cycles.list.path] }),
  });
}
