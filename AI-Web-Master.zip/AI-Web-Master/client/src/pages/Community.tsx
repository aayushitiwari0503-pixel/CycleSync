import React, { useState } from "react";
import { motion } from "framer-motion";
import { Shell } from "@/components/layout/Shell";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { usePosts, useCreatePost, useUpvotePost } from "@/hooks/use-posts";
import { Heart, MessageCircle, ShieldCheck } from "lucide-react";
import { format } from "date-fns";

export default function Community() {
  const { data: posts, isLoading } = usePosts();
  const createPost = useCreatePost();
  const upvotePost = useUpvotePost();

  const [newPost, setNewPost] = useState("");

  const handleCreate = () => {
    if (!newPost.trim()) return;
    createPost.mutate({ content: newPost, category: "General", authorId: 1 }, {
      onSuccess: () => setNewPost("")
    });
  };

  return (
    <Shell>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8 max-w-3xl mx-auto">
        <div className="text-center">
          <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground">Support Wall</h1>
          <p className="text-muted-foreground mt-2">A safe, anonymous space to vent, ask, and support each other.</p>
        </div>

        {/* Create Post */}
        <Card className="p-2 border-2 border-primary/20 bg-white/80">
          <textarea 
            value={newPost}
            onChange={(e) => setNewPost(e.target.value)}
            placeholder="Share how you're feeling today..."
            className="w-full bg-transparent border-none p-4 focus:outline-none resize-none min-h-[100px] text-foreground font-medium"
          />
          <div className="flex justify-between items-center p-2">
            <div className="flex gap-2">
              <span className="bg-muted px-3 py-1 rounded-full text-xs font-bold text-muted-foreground cursor-pointer hover:bg-muted/80">#Venting</span>
              <span className="bg-muted px-3 py-1 rounded-full text-xs font-bold text-muted-foreground cursor-pointer hover:bg-muted/80">#Advice</span>
            </div>
            <Button size="sm" onClick={handleCreate} disabled={createPost.isPending || !newPost.trim()}>
              {createPost.isPending ? "Posting..." : "Post Anonymously"}
            </Button>
          </div>
        </Card>

        {/* Feed */}
        <div className="space-y-4">
          {isLoading ? (
            <div className="animate-pulse space-y-4">
              <Card className="h-32 bg-muted/50"></Card>
              <Card className="h-32 bg-muted/50"></Card>
            </div>
          ) : posts?.map((post) => (
            <Card key={post.id} className="p-5 md:p-6 transition-transform hover:-translate-y-0.5">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-secondary to-accent flex items-center justify-center">
                    <span className="text-white font-bold text-sm">Anon</span>
                  </div>
                  <div>
                    <p className="font-bold text-sm">Anonymous user</p>
                    <p className="text-xs text-muted-foreground">{post.createdAt ? format(new Date(post.createdAt), 'MMM d, yyyy') : 'Just now'}</p>
                  </div>
                </div>
                {post.verifiedMedicalAdvice && (
                  <span className="flex items-center gap-1 text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md">
                    <ShieldCheck className="w-3 h-3" /> Expert Verified
                  </span>
                )}
              </div>
              <p className="text-foreground/90 font-medium leading-relaxed mb-4 whitespace-pre-wrap">
                {post.content}
              </p>
              <div className="flex items-center gap-4 border-t border-border pt-3">
                <button 
                  onClick={() => upvotePost.mutate(post.id)}
                  className="flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors font-semibold text-sm group"
                >
                  <Heart className="w-4 h-4 group-active:scale-125 transition-transform" /> {post.upvotes || 0}
                </button>
                <button className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors font-semibold text-sm">
                  <MessageCircle className="w-4 h-4" /> Reply
                </button>
              </div>
            </Card>
          ))}
        </div>
      </motion.div>
    </Shell>
  );
}
