import React from "react";
import { motion } from "framer-motion";
import { Shell } from "@/components/layout/Shell";
import { Card } from "@/components/ui/Card";
import { Play } from "lucide-react";

const EXERCISES = [
  {
    title: "Gentle Flow for Severe Cramps",
    duration: "15 min",
    level: "Beginner",
    // Unsplash: yoga mat gentle stretch
    img: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800&q=80"
  },
  {
    title: "Pelvic Floor Relaxation",
    duration: "10 min",
    level: "All levels",
    // Unsplash: meditation/relaxation
    img: "https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=800&q=80"
  },
  {
    title: "Lower Back Release Sequence",
    duration: "20 min",
    level: "Beginner",
    // Unsplash: back stretching
    img: "https://images.unsplash.com/photo-1552196563-552592624f2b?w=800&q=80"
  }
];

export default function Exercises() {
  return (
    <Shell>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
        <div>
          <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground">Cramp Relief Hub</h1>
          <p className="text-muted-foreground mt-2">Movement designed to soothe, not stress, your body right now.</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {EXERCISES.map((ex, i) => (
            <Card key={i} className="p-0 overflow-hidden relative group cursor-pointer border-none shadow-md hover:shadow-2xl transition-all duration-300">
              <div className="h-64 overflow-hidden relative">
                <img 
                  src={ex.img} 
                  alt={ex.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-16 h-16 bg-white/30 backdrop-blur-md rounded-full flex items-center justify-center text-white">
                    <Play className="w-6 h-6 ml-1" />
                  </div>
                </div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 p-5 bg-gradient-to-t from-black/90 to-transparent text-white">
                <div className="flex gap-2 mb-2">
                  <span className="text-[10px] font-bold bg-white/20 backdrop-blur-md px-2 py-1 rounded-md uppercase tracking-wider">{ex.duration}</span>
                  <span className="text-[10px] font-bold bg-white/20 backdrop-blur-md px-2 py-1 rounded-md uppercase tracking-wider">{ex.level}</span>
                </div>
                <h3 className="font-bold text-xl leading-tight">{ex.title}</h3>
              </div>
            </Card>
          ))}
        </div>
      </motion.div>
    </Shell>
  );
}
