import React from "react";
import { motion } from "framer-motion";
import { format, addDays, subDays, isSameDay } from "date-fns";
import { Shell } from "@/components/layout/Shell";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Droplets, Calendar as CalendarIcon, HeartPulse, Sparkles } from "lucide-react";
import { useLogs } from "@/hooks/use-logs";

export default function Dashboard() {
  const { data: logs, isLoading } = useLogs();
  
  // Generate a mock 7-day strip centered on today
  const today = new Date();
  const weekDays = Array.from({ length: 7 }).map((_, i) => addDays(subDays(today, 3), i));

  // Mock scores and phases
  const selfCareScore = 85;
  const cycleDay = 14;
  const phase = "Ovulatory Phase";

  return (
    <Shell>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground">Good morning, Sarah.</h1>
            <p className="text-muted-foreground mt-1">You're on day {cycleDay} of your cycle. Your body is glowing!</p>
          </div>
          <div className="flex items-center gap-3 bg-white/50 backdrop-blur-md px-5 py-3 rounded-2xl shadow-sm border border-white">
            <div className="bg-primary/20 p-2 rounded-full">
              <HeartPulse className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Self-Care Score</p>
              <p className="text-xl font-black text-foreground">{selfCareScore}<span className="text-muted-foreground text-sm font-medium">/100</span></p>
            </div>
          </div>
        </div>

        {/* Calendar Strip */}
        <Card className="p-4 md:p-6 bg-gradient-to-br from-white to-white/40">
          <div className="flex items-center justify-between mb-4 px-2">
            <h3 className="font-bold flex items-center gap-2"><CalendarIcon className="w-4 h-4 text-primary" /> This Week</h3>
            <span className="text-xs font-semibold bg-secondary/50 text-secondary-foreground px-3 py-1 rounded-full">{phase}</span>
          </div>
          <div className="grid grid-cols-7 gap-2 md:gap-4">
            {weekDays.map((date, i) => {
              const isToday = isSameDay(date, today);
              const hasLog = logs?.some(l => isSameDay(new Date(l.date), date));
              
              return (
                <div 
                  key={i} 
                  className={`flex flex-col items-center justify-center p-3 md:p-4 rounded-2xl transition-all ${
                    isToday ? "bg-primary text-white shadow-lg shadow-primary/30" : "bg-muted/30 hover:bg-muted/60"
                  }`}
                >
                  <span className={`text-xs font-semibold mb-1 ${isToday ? "text-primary-foreground/80" : "text-muted-foreground"}`}>
                    {format(date, 'EEE')}
                  </span>
                  <span className="text-lg md:text-xl font-bold">
                    {format(date, 'd')}
                  </span>
                  {hasLog && (
                    <div className={`w-1.5 h-1.5 rounded-full mt-2 ${isToday ? "bg-white" : "bg-primary"}`} />
                  )}
                </div>
              );
            })}
          </div>
        </Card>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Smart Predictions */}
          <Card className="bg-gradient-to-br from-secondary/30 to-transparent">
            <h3 className="font-bold mb-4 flex items-center gap-2"><Sparkles className="w-4 h-4 text-accent" /> AI Insights</h3>
            <div className="space-y-4">
              <div className="bg-white/60 p-4 rounded-2xl">
                <p className="font-medium text-sm">Energy levels peaking today! Great time for that high-intensity workout or big project.</p>
              </div>
              <div className="bg-white/60 p-4 rounded-2xl">
                <p className="font-medium text-sm">Next period predicted in <span className="font-bold text-primary">14 days</span>.</p>
              </div>
            </div>
            <Button variant="glass" className="w-full mt-4 text-sm font-semibold">View Full Insights</Button>
          </Card>

          {/* Recent Logs */}
          <Card>
            <h3 className="font-bold mb-4 flex items-center gap-2"><Droplets className="w-4 h-4 text-primary" /> Recent Logs</h3>
            {isLoading ? (
              <div className="animate-pulse space-y-3">
                <div className="h-16 bg-muted/50 rounded-2xl"></div>
                <div className="h-16 bg-muted/50 rounded-2xl"></div>
              </div>
            ) : logs && logs.length > 0 ? (
              <div className="space-y-3">
                {logs.slice(0, 3).map(log => (
                  <div key={log.id} className="flex items-center gap-4 p-3 rounded-2xl hover:bg-muted/30 transition-colors border border-transparent hover:border-border">
                    <div className="bg-muted p-3 rounded-xl">
                      <Droplets className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="font-semibold text-sm">{log.symptoms?.[0] || 'Logged feeling'} • {log.mood || 'Neutral'}</p>
                      <p className="text-xs text-muted-foreground">{format(new Date(log.date), 'MMM d, h:mm a')}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground text-sm">No logs yet today. Listen to your body and log how you feel!</p>
              </div>
            )}
          </Card>
        </div>
      </motion.div>
    </Shell>
  );
}
