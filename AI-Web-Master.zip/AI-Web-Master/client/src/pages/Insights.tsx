import React, { useEffect } from "react";
import { motion } from "framer-motion";
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { Shell } from "@/components/layout/Shell";
import { Card } from "@/components/ui/Card";
import { Brain, Target, BatteryCharging } from "lucide-react";
import { useCycleInsights } from "@/hooks/use-ai";

export default function Insights() {
  const { mutate: getInsights, data, isPending } = useCycleInsights();

  useEffect(() => {
    // Fetch insights on mount
    getInsights({ cycleId: 1 });
  }, [getInsights]);

  // Fallback beautiful mock data if API fails or is loading
  const graphData = data?.energyGraph || [
    { day: 1, energyLevel: 20 },
    { day: 5, energyLevel: 40 },
    { day: 10, energyLevel: 80 },
    { day: 14, energyLevel: 95 },
    { day: 20, energyLevel: 70 },
    { day: 25, energyLevel: 40 },
    { day: 28, energyLevel: 30 },
  ];

  return (
    <Shell>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
        <div>
          <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground">Productivity & Mood</h1>
          <p className="text-muted-foreground mt-2">Sync your life with your biology. Here is your AI-powered energy forecast.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <Card className="bg-gradient-to-br from-primary/10 to-transparent">
            <BatteryCharging className="w-6 h-6 text-primary mb-3" />
            <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-1">Current Phase</h3>
            <p className="text-2xl font-black text-foreground">{data?.phase || "Ovulatory"}</p>
          </Card>
          
          <Card className="md:col-span-2 bg-gradient-to-br from-accent/10 to-transparent">
            <Target className="w-6 h-6 text-accent mb-3" />
            <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-1">Focus Window</h3>
            <p className="text-lg font-bold text-foreground leading-tight">
              {data?.focusWindow || "Peak energy! Schedule big presentations, social events, and intense workouts for the next 3 days."}
            </p>
          </Card>
        </div>

        <Card className="p-6 md:p-8">
          <div className="flex items-center justify-between mb-8">
            <h3 className="font-bold text-xl flex items-center gap-2">
              <Brain className="w-5 h-5 text-secondary-foreground" /> 
              Energy Projection Graph
            </h3>
            {isPending && <span className="text-sm text-muted-foreground animate-pulse">Generating AI insights...</span>}
          </div>
          
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={graphData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorEnergy" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 25px rgba(0,0,0,0.1)' }}
                  labelStyle={{ fontWeight: 'bold', color: 'hsl(var(--foreground))' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="energyLevel" 
                  stroke="hsl(var(--primary))" 
                  strokeWidth={4}
                  fillOpacity={1} 
                  fill="url(#colorEnergy)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {data?.recommendations && (
          <Card>
            <h3 className="font-bold text-xl mb-4">AI Recommendations</h3>
            <ul className="space-y-3">
              {data.recommendations.map((rec, i) => (
                <li key={i} className="flex gap-3 text-foreground/80 font-medium">
                  <span className="text-primary font-bold">{i + 1}.</span> {rec}
                </li>
              ))}
            </ul>
          </Card>
        )}
      </motion.div>
    </Shell>
  );
}
