import React, { useState } from "react";
import { motion } from "framer-motion";
import { Shell } from "@/components/layout/Shell";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Sparkles, AlertTriangle, Coffee, Activity, ArrowRight } from "lucide-react";
import { useSymptomRemedy } from "@/hooks/use-ai";

const SYMPTOMS_DB = ["Severe Cramps", "Lower Back Pain", "Nausea", "Migraine", "Bloating", "Insomnia", "Anxiety", "Tender Breasts"];

export default function AIRemedies() {
  const [selected, setSelected] = useState<string[]>([]);
  const { mutate: getRemedy, data: remedy, isPending } = useSymptomRemedy();

  const handleToggle = (sym: string) => {
    setSelected(prev => prev.includes(sym) ? prev.filter(s => s !== sym) : [...prev, sym]);
  };

  const handleAnalyze = () => {
    if (selected.length === 0) return;
    getRemedy({ symptoms: selected });
  };

  return (
    <Shell>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8 max-w-3xl mx-auto">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center justify-center p-3 bg-primary/10 rounded-full mb-2">
            <Sparkles className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-3xl md:text-4xl font-display font-bold">AI Symptom-to-Solution</h1>
          <p className="text-muted-foreground text-lg">Tell Cy exactly how you're feeling, and we'll craft a personalized relief plan in seconds.</p>
        </div>

        <Card className="bg-gradient-to-br from-white to-primary/5 border-primary/20">
          <h3 className="font-bold mb-4">Select your current symptoms:</h3>
          <div className="flex flex-wrap gap-2 mb-6">
            {SYMPTOMS_DB.map(sym => (
              <button
                key={sym}
                onClick={() => handleToggle(sym)}
                className={`px-4 py-2.5 rounded-full text-sm font-semibold transition-all ${
                  selected.includes(sym) 
                    ? "bg-primary text-white shadow-md scale-105" 
                    : "bg-white border border-border text-foreground/70 hover:border-primary/40"
                }`}
              >
                {sym}
              </button>
            ))}
          </div>
          <Button 
            className="w-full" 
            size="lg" 
            onClick={handleAnalyze} 
            disabled={selected.length === 0 || isPending}
          >
            {isPending ? "Analyzing..." : "Generate My Relief Plan"} <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </Card>

        {remedy && (
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="space-y-6">
            {remedy.emergencyFlag && (
              <div className="bg-destructive/10 border border-destructive/30 p-4 rounded-2xl flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
                <p className="text-sm font-medium text-destructive-foreground/90">
                  Based on your symptoms, we strongly recommend consulting a healthcare provider immediately.
                </p>
              </div>
            )}

            <div className="grid md:grid-cols-2 gap-4">
              <Card className="bg-[#F8F9FA]">
                <h4 className="font-bold flex items-center gap-2 mb-3"><Sparkles className="w-4 h-4 text-accent" /> Immediate Remedies</h4>
                <ul className="space-y-2">
                  {remedy.remedies.map((item, i) => (
                    <li key={i} className="text-sm flex items-start gap-2">
                      <span className="text-primary mt-1">•</span> {item}
                    </li>
                  ))}
                </ul>
              </Card>

              <Card className="bg-[#FDF8F5]">
                <h4 className="font-bold flex items-center gap-2 mb-3"><Coffee className="w-4 h-4 text-orange-400" /> Nutrition Fixes</h4>
                <ul className="space-y-2">
                  {remedy.diet.map((item, i) => (
                    <li key={i} className="text-sm flex items-start gap-2">
                      <span className="text-orange-400 mt-1">•</span> {item}
                    </li>
                  ))}
                </ul>
              </Card>
            </div>

            <Card className="bg-secondary/10">
              <h4 className="font-bold flex items-center gap-2 mb-3"><Activity className="w-4 h-4 text-secondary-foreground" /> Recommended Stretches</h4>
              <ul className="space-y-2">
                {remedy.stretches.map((item, i) => (
                  <li key={i} className="text-sm flex items-start gap-2">
                    <span className="text-secondary-foreground mt-1">•</span> {item}
                  </li>
                ))}
              </ul>
            </Card>
          </motion.div>
        )}
      </motion.div>
    </Shell>
  );
}
