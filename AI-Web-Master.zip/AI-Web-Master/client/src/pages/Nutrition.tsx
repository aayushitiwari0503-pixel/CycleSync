import React from "react";
import { motion } from "framer-motion";
import { Shell } from "@/components/layout/Shell";
import { Card } from "@/components/ui/Card";
import { Search } from "lucide-react";

const RECIPES = [
  {
    title: "Anti-inflammatory Golden Milk",
    category: "Drink",
    time: "10 min",
    // Unsplash: turmeric latte / golden milk
    img: "https://images.unsplash.com/photo-1611162458324-aae1eb4129a4?w=800&q=80" 
  },
  {
    title: "Warm Quinoa & Roasted Veggie Bowl",
    category: "Lunch",
    time: "25 min",
    // Unsplash: healthy quinoa bowl
    img: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=800&q=80"
  },
  {
    title: "Dark Chocolate Iron-Boost Bites",
    category: "Snack",
    time: "15 min",
    // Unsplash: dark chocolate pieces
    img: "https://images.unsplash.com/photo-1606312619070-d48b4c652a52?w=800&q=80"
  },
  {
    title: "Soothing Ginger & Tulsi Tea",
    category: "Drink",
    time: "5 min",
    // Unsplash: herbal tea
    img: "https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&q=80"
  }
];

export default function Nutrition() {
  return (
    <Shell>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
        <div>
          <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground">Period Nutrition Planner</h1>
          <p className="text-muted-foreground mt-2">Nourish your body with phase-specific, anti-inflammatory recipes.</p>
        </div>

        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
          <input 
            type="text" 
            placeholder="Search for ingredients, cravings, or recipes..." 
            className="w-full bg-white border-none shadow-[0_4px_20px_rgba(0,0,0,0.03)] rounded-2xl py-4 pl-12 pr-4 focus:ring-4 focus:ring-primary/20 transition-all font-medium"
          />
        </div>

        <div className="flex gap-2 overflow-x-auto hide-scrollbar pb-2">
          {["All", "Luteal Phase", "Follicular Phase", "Menstrual", "Iron-Rich", "Craving Crushers"].map((tag, i) => (
            <button key={tag} className={`whitespace-nowrap px-5 py-2 rounded-full text-sm font-semibold transition-all ${i === 0 ? 'bg-foreground text-background' : 'bg-white text-foreground/70 hover:bg-muted'}`}>
              {tag}
            </button>
          ))}
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {RECIPES.map((recipe, i) => (
            <Card key={i} className="p-0 overflow-hidden group cursor-pointer border-none shadow-md hover:shadow-xl">
              <div className="h-48 overflow-hidden">
                <img 
                  src={recipe.img} 
                  alt={recipe.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
              </div>
              <div className="p-5">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-bold text-primary uppercase tracking-wider">{recipe.category}</span>
                  <span className="text-xs text-muted-foreground font-semibold bg-muted/50 px-2 py-1 rounded-md">{recipe.time}</span>
                </div>
                <h3 className="font-bold text-lg leading-tight text-foreground">{recipe.title}</h3>
              </div>
            </Card>
          ))}
        </div>
      </motion.div>
    </Shell>
  );
}
