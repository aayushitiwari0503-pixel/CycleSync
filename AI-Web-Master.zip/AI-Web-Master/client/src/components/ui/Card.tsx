import * as React from "react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function Card({ className, children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn("glass-panel rounded-3xl p-6 transition-all duration-300 hover:shadow-[0_12px_40px_rgba(0,0,0,0.06)]", className)} {...props}>
      {children}
    </div>
  );
}
