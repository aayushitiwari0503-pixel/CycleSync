import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { Calendar, Sparkles, Apple, Activity, BarChart2, Users, Plus } from "lucide-react";
import { LogSymptomModal } from "../LogSymptomModal";

const NAV_ITEMS = [
  { href: "/", label: "Dashboard", icon: Calendar },
  { href: "/ai-remedies", label: "AI Remedies", icon: Sparkles },
  { href: "/nutrition", label: "Nutrition", icon: Apple },
  { href: "/exercises", label: "Exercises", icon: Activity },
  { href: "/insights", label: "Insights", icon: BarChart2 },
  { href: "/community", label: "Community", icon: Users },
];

export function Shell({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);

  return (
    <div className="flex min-h-screen">
      {/* Sidebar (Desktop) */}
      <aside className="hidden md:flex flex-col w-72 fixed inset-y-0 left-0 border-r border-border/50 glass-panel z-10">
        <div className="p-8 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-primary to-accent flex items-center justify-center text-white shadow-lg">
              <Sparkles className="w-5 h-5" />
            </div>
            <h1 className="text-2xl font-display font-bold text-gradient">Cy.</h1>
          </div>
        </div>
        
        <nav className="flex-1 px-4 py-6 space-y-2">
          {NAV_ITEMS.map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;
            return (
              <Link key={item.href} href={item.href} className={`flex items-center gap-4 px-4 py-3 rounded-2xl transition-all duration-200 ${isActive ? "bg-primary/10 text-primary font-bold shadow-sm" : "text-foreground/70 hover:bg-muted hover:text-foreground font-medium"}`}>
                <Icon className={`w-5 h-5 ${isActive ? "text-primary" : ""}`} />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="p-6 mt-auto">
          <button 
            onClick={() => setIsLogModalOpen(true)}
            className="w-full flex items-center justify-center gap-2 bg-foreground text-background py-4 rounded-2xl font-bold shadow-xl hover:shadow-2xl hover:-translate-y-1 transition-all duration-300"
          >
            <Plus className="w-5 h-5" /> Log Symptom
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 md:pl-72 pb-24 md:pb-0">
        <div className="max-w-5xl mx-auto p-4 md:p-8">
          {children}
        </div>
      </main>

      {/* Bottom Nav (Mobile) */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 glass-panel border-t border-border/50 pb-safe z-20">
        <nav className="flex items-center justify-around p-2">
          {NAV_ITEMS.slice(0, 5).map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;
            return (
              <Link key={item.href} href={item.href} className={`flex flex-col items-center p-2 rounded-xl transition-all ${isActive ? "text-primary" : "text-muted-foreground"}`}>
                <Icon className={`w-6 h-6 mb-1 ${isActive ? "scale-110" : ""}`} />
                <span className="text-[10px] font-medium">{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </div>

      {/* Mobile FAB */}
      <button 
        onClick={() => setIsLogModalOpen(true)}
        className="md:hidden fixed bottom-20 right-4 w-14 h-14 bg-foreground text-background rounded-full shadow-2xl flex items-center justify-center z-30 active:scale-95 transition-transform"
      >
        <Plus className="w-6 h-6" />
      </button>

      <LogSymptomModal isOpen={isLogModalOpen} onClose={() => setIsLogModalOpen(false)} />
    </div>
  );
}
