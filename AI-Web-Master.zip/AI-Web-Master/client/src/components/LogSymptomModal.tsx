import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Droplets, Smile, Frown, Thermometer, Wind, Zap } from "lucide-react";
import { Button } from "./ui/Button";
import { useCreateLog } from "@/hooks/use-logs";
import { useToast } from "@/hooks/use-toast";

const COMMON_SYMPTOMS = ["Cramps", "Bloating", "Headache", "Fatigue", "Acne", "Cravings"];
const MOODS = [
  { icon: Smile, label: "Happy" },
  { icon: Zap, label: "Energetic" },
  { icon: Frown, label: "Sad" },
  { icon: Wind, label: "Anxious" }
];

export function LogSymptomModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [severity, setSeverity] = useState(3);
  const [notes, setNotes] = useState("");
  
  const { toast } = useToast();
  const createLog = useCreateLog();

  const handleToggleSymptom = (sym: string) => {
    setSelectedSymptoms(prev => 
      prev.includes(sym) ? prev.filter(s => s !== sym) : [...prev, sym]
    );
  };

  const handleSubmit = () => {
    createLog.mutate(
      {
        userId: 1, // Mock user ID for now
        date: new Date(),
        symptoms: selectedSymptoms,
        mood: selectedMood,
        severity,
        notes
      },
      {
        onSuccess: () => {
          toast({ title: "Logged successfully!", description: "Your symptoms have been recorded." });
          onClose();
          // Reset form
          setSelectedSymptoms([]);
          setSelectedMood(null);
          setSeverity(3);
          setNotes("");
        },
        onError: () => {
          toast({ title: "Error", description: "Could not log symptoms.", variant: "destructive" });
        }
      }
    );
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50"
          />
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-lg z-50 p-4"
          >
            <div className="bg-card rounded-[2rem] shadow-2xl border border-border/50 overflow-hidden">
              <div className="p-6 md:p-8">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-display font-bold text-foreground">Log Today's Status</h2>
                  <button onClick={onClose} className="p-2 rounded-full hover:bg-muted text-muted-foreground transition-colors">
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-6">
                  {/* Symptoms */}
                  <div>
                    <label className="text-sm font-semibold text-foreground/80 mb-3 block">What are you feeling?</label>
                    <div className="flex flex-wrap gap-2">
                      {COMMON_SYMPTOMS.map(sym => (
                        <button
                          key={sym}
                          onClick={() => handleToggleSymptom(sym)}
                          className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                            selectedSymptoms.includes(sym) 
                              ? "bg-primary text-primary-foreground shadow-md" 
                              : "bg-muted text-muted-foreground hover:bg-muted/80"
                          }`}
                        >
                          {sym}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Mood */}
                  <div>
                    <label className="text-sm font-semibold text-foreground/80 mb-3 block">Mood</label>
                    <div className="grid grid-cols-4 gap-3">
                      {MOODS.map(({ icon: Icon, label }) => (
                        <button
                          key={label}
                          onClick={() => setSelectedMood(label)}
                          className={`flex flex-col items-center justify-center p-3 rounded-2xl transition-all ${
                            selectedMood === label 
                              ? "bg-secondary text-secondary-foreground shadow-inner" 
                              : "bg-muted/50 text-muted-foreground hover:bg-muted"
                          }`}
                        >
                          <Icon className="w-6 h-6 mb-2" />
                          <span className="text-xs font-medium">{label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Severity */}
                  <div>
                    <div className="flex justify-between mb-2">
                      <label className="text-sm font-semibold text-foreground/80">Flow / Pain Severity</label>
                      <span className="text-xs font-bold text-primary">{severity}/5</span>
                    </div>
                    <input 
                      type="range" 
                      min="1" max="5" 
                      value={severity} 
                      onChange={(e) => setSeverity(parseInt(e.target.value))}
                      className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"
                    />
                  </div>

                  {/* Notes */}
                  <div>
                    <label className="text-sm font-semibold text-foreground/80 mb-3 block">Private Notes</label>
                    <textarea 
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Any thoughts or specific triggers today?"
                      className="w-full bg-muted/30 border-2 border-muted rounded-2xl p-4 text-sm focus:outline-none focus:border-primary/50 focus:ring-4 focus:ring-primary/10 transition-all resize-none h-24"
                    />
                  </div>
                </div>

                <div className="mt-8">
                  <Button 
                    className="w-full" 
                    size="lg" 
                    onClick={handleSubmit}
                    disabled={createLog.isPending}
                  >
                    {createLog.isPending ? "Saving..." : "Save Daily Log"}
                  </Button>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
