import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

// Pages
import Dashboard from "./pages/Dashboard";
import AIRemedies from "./pages/AIRemedies";
import Nutrition from "./pages/Nutrition";
import Exercises from "./pages/Exercises";
import Insights from "./pages/Insights";
import Community from "./pages/Community";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard}/>
      <Route path="/ai-remedies" component={AIRemedies}/>
      <Route path="/nutrition" component={Nutrition}/>
      <Route path="/exercises" component={Exercises}/>
      <Route path="/insights" component={Insights}/>
      <Route path="/community" component={Community}/>
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
