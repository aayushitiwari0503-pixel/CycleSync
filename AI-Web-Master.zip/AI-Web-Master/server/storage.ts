import { db } from "./db";
import {
  users, cycles, logs, posts,
  type User, type InsertUser,
  type Cycle, type InsertCycle,
  type Log, type InsertLog,
  type Post, type InsertPost
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserSettings(id: number, settings: Partial<InsertUser>): Promise<User>;

  getCycles(userId: number): Promise<Cycle[]>;
  createCycle(cycle: InsertCycle): Promise<Cycle>;

  getLogs(userId: number): Promise<Log[]>;
  createLog(log: InsertLog): Promise<Log>;

  getPosts(): Promise<Post[]>;
  createPost(post: InsertPost): Promise<Post>;
  upvotePost(id: number): Promise<Post | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserSettings(id: number, settings: Partial<InsertUser>): Promise<User> {
    const [user] = await db.update(users).set(settings).where(eq(users.id, id)).returning();
    return user;
  }

  async getCycles(userId: number): Promise<Cycle[]> {
    return await db.select().from(cycles).where(eq(cycles.userId, userId)).orderBy(desc(cycles.startDate));
  }

  async createCycle(insertCycle: InsertCycle): Promise<Cycle> {
    const [cycle] = await db.insert(cycles).values(insertCycle).returning();
    return cycle;
  }

  async getLogs(userId: number): Promise<Log[]> {
    return await db.select().from(logs).where(eq(logs.userId, userId)).orderBy(desc(logs.date));
  }

  async createLog(insertLog: InsertLog): Promise<Log> {
    const [log] = await db.insert(logs).values(insertLog).returning();
    return log;
  }

  async getPosts(): Promise<Post[]> {
    return await db.select().from(posts).orderBy(desc(posts.createdAt));
  }

  async createPost(insertPost: InsertPost): Promise<Post> {
    const [post] = await db.insert(posts).values(insertPost).returning();
    return post;
  }

  async upvotePost(id: number): Promise<Post | undefined> {
    const [post] = await db.select().from(posts).where(eq(posts.id, id));
    if (!post) return undefined;
    
    const [updatedPost] = await db.update(posts)
      .set({ upvotes: (post.upvotes || 0) + 1 })
      .where(eq(posts.id, id))
      .returning();
    return updatedPost;
  }
}

export const storage = new DatabaseStorage();