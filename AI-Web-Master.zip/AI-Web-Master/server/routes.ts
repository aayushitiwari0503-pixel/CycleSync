import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  // --- USER ROUTES ---
  app.get(api.users.me.path, async (req, res) => {
    // For now, mock user 1
    const user = await storage.getUser(1);
    res.json(user || null);
  });

  app.put(api.users.updateSettings.path, async (req, res) => {
    try {
      const input = api.users.updateSettings.input.parse(req.body);
      const user = await storage.updateUserSettings(1, input);
      res.json(user);
    } catch (e) {
      if (e instanceof z.ZodError) res.status(400).json({ message: e.errors[0].message });
    }
  });

  // --- CYCLES ROUTES ---
  app.get(api.cycles.list.path, async (req, res) => {
    const cyclesList = await storage.getCycles(1);
    res.json(cyclesList);
  });

  app.post(api.cycles.create.path, async (req, res) => {
    try {
      // Coerce dates from strings if necessary
      const input = api.cycles.create.input.parse({
        ...req.body,
        startDate: new Date(req.body.startDate),
        endDate: req.body.endDate ? new Date(req.body.endDate) : undefined,
      });
      const cycle = await storage.createCycle(input);
      res.status(201).json(cycle);
    } catch (e) {
      if (e instanceof z.ZodError) res.status(400).json({ message: e.errors[0].message });
    }
  });

  // --- LOGS ROUTES ---
  app.get(api.logs.list.path, async (req, res) => {
    const logsList = await storage.getLogs(1);
    res.json(logsList);
  });

  app.post(api.logs.create.path, async (req, res) => {
    try {
      const input = api.logs.create.input.parse({
        ...req.body,
        date: new Date(req.body.date),
      });
      const log = await storage.createLog(input);
      res.status(201).json(log);
    } catch (e) {
      if (e instanceof z.ZodError) res.status(400).json({ message: e.errors[0].message });
    }
  });

  // --- POSTS ROUTES ---
  app.get(api.posts.list.path, async (req, res) => {
    const postsList = await storage.getPosts();
    res.json(postsList);
  });

  app.post(api.posts.create.path, async (req, res) => {
    try {
      const input = api.posts.create.input.parse(req.body);
      const post = await storage.createPost(input);
      res.status(201).json(post);
    } catch (e) {
      if (e instanceof z.ZodError) res.status(400).json({ message: e.errors[0].message });
    }
  });

  app.post(api.posts.upvote.path, async (req, res) => {
    const post = await storage.upvotePost(Number(req.params.id));
    if (!post) return res.status(404).json({ message: "Post not found" });
    res.json(post);
  });

  // --- AI ROUTES (Mocked initially for quick response) ---
  app.post(api.ai.symptomRemedy.path, async (req, res) => {
    try {
      const { symptoms } = req.body;
      
      const remedies = ["Drink chamomile tea", "Use a heating pad", "Rest in a quiet room"];
      const diet = ["Ginger", "Dark chocolate", "Leafy greens", "Turmeric"];
      const stretches = ["Child's pose", "Knee-to-chest stretch"];
      
      const seeDoctor = symptoms?.some((s: string) => 
        s.toLowerCase().includes("severe") || s.toLowerCase().includes("extreme")
      ) || false;
      
      res.json({
        remedies,
        diet,
        stretches,
        seeDoctor,
        emergencyFlag: seeDoctor
      });
    } catch (e) {
      res.status(500).json({ message: "AI processing failed" });
    }
  });

  app.post(api.ai.cycleInsights.path, async (req, res) => {
    try {
      res.json({
        phase: "Luteal",
        focusWindow: "Starts in 2 days",
        energyGraph: [
          { day: 1, energyLevel: 3 },
          { day: 7, energyLevel: 8 },
          { day: 14, energyLevel: 9 },
          { day: 21, energyLevel: 5 },
          { day: 28, energyLevel: 4 },
        ],
        recommendations: [
          "Focus on light, creative tasks today.",
          "Avoid high-stress presentations if possible.",
          "Good day for steady, low-impact exercise."
        ]
      });
    } catch (e) {
      res.status(500).json({ message: "Failed to generate insights" });
    }
  });

  // SEED DATABASE ON STARTUP
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  let user = await storage.getUser(1);
  if (!user) {
    user = await storage.createUser({
      email: "demo@cyclesync.com",
      displayName: "Jane Doe",
      cycleLengthDays: 28,
      periodLengthDays: 5
    });
  }

  const posts = await storage.getPosts();
  if (posts.length === 0) {
    await storage.createPost({
      content: "Does anyone else get severe back pain right before their cycle? What helps?",
      authorId: user.id,
      category: "Symptoms"
    });
    const p2 = await storage.createPost({
      content: "Ginger tea really helps with my nausea!",
      authorId: user.id,
      category: "Remedies"
    });
    await storage.upvotePost(p2.id);
  }
}