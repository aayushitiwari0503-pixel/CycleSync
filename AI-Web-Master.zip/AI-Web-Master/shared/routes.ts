import { z } from 'zod';
import { insertUserSchema, insertCycleSchema, insertLogSchema, insertPostSchema, users, cycles, logs, posts } from './schema';

export const errorSchemas = {
  validation: z.object({ message: z.string(), field: z.string().optional() }),
  notFound: z.object({ message: z.string() }),
  internal: z.object({ message: z.string() }),
};

export const api = {
  users: {
    me: {
      method: 'GET' as const,
      path: '/api/users/me' as const,
      responses: {
        200: z.custom<typeof users.$inferSelect>().nullable(),
      },
    },
    updateSettings: {
      method: 'PUT' as const,
      path: '/api/users/me/settings' as const,
      input: insertUserSchema.partial(),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        400: errorSchemas.validation,
      }
    }
  },
  cycles: {
    list: {
      method: 'GET' as const,
      path: '/api/cycles' as const,
      responses: { 200: z.array(z.custom<typeof cycles.$inferSelect>()) }
    },
    create: {
      method: 'POST' as const,
      path: '/api/cycles' as const,
      input: insertCycleSchema,
      responses: { 201: z.custom<typeof cycles.$inferSelect>(), 400: errorSchemas.validation }
    }
  },
  logs: {
    list: {
      method: 'GET' as const,
      path: '/api/logs' as const,
      responses: { 200: z.array(z.custom<typeof logs.$inferSelect>()) }
    },
    create: {
      method: 'POST' as const,
      path: '/api/logs' as const,
      input: insertLogSchema,
      responses: { 201: z.custom<typeof logs.$inferSelect>(), 400: errorSchemas.validation }
    }
  },
  posts: {
    list: {
      method: 'GET' as const,
      path: '/api/posts' as const,
      responses: { 200: z.array(z.custom<typeof posts.$inferSelect>()) }
    },
    create: {
      method: 'POST' as const,
      path: '/api/posts' as const,
      input: insertPostSchema,
      responses: { 201: z.custom<typeof posts.$inferSelect>(), 400: errorSchemas.validation }
    },
    upvote: {
      method: 'POST' as const,
      path: '/api/posts/:id/upvote' as const,
      responses: { 200: z.custom<typeof posts.$inferSelect>(), 404: errorSchemas.notFound }
    }
  },
  ai: {
    symptomRemedy: {
      method: 'POST' as const,
      path: '/api/ai/remedy' as const,
      input: z.object({ symptoms: z.array(z.string()) }),
      responses: {
        200: z.object({
          remedies: z.array(z.string()),
          diet: z.array(z.string()),
          stretches: z.array(z.string()),
          seeDoctor: z.boolean(),
          emergencyFlag: z.boolean()
        }),
        500: errorSchemas.internal
      }
    },
    cycleInsights: {
      method: 'POST' as const,
      path: '/api/ai/insights' as const,
      input: z.object({ cycleId: z.number().optional() }),
      responses: {
        200: z.object({
          phase: z.string(),
          focusWindow: z.string(),
          energyGraph: z.array(z.object({ day: z.number(), energyLevel: z.number() })),
          recommendations: z.array(z.string())
        }),
        500: errorSchemas.internal
      }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}